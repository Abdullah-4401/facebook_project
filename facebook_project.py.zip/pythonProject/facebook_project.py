class User:
    def __init__(self, name, email):
        self.name = name
        self.email = email
        self.friends = []

    def add_friend(self, friend):
        self.friends.append(friend)

    def remove_friend(self, friend):
        self.friends.remove(friend)

    def create_post(self, content, page):
        page.add_post(content, self)

    def like_post(self, post):
        post.add_like(self)

class Post:
    def __init__(self, content, author):
        self.content = content
        self.author = author
        self.likes = []
        self.comments=[]


    def add_like(self, user):
        self.likes.append(user)
    def add_comment(self,user):
        self.comments.append(user)

class Admin_Page:
    def __init__(self, name):
        self.name = name
        self.posts = []

    def add_post(self, content, author):
        post = Post(content, author)
        self.posts.append(post)

# Example usage
user1 = User("Alice", "alice@example.com")
user2 = User("Bob", "bob@example.com")

user1.add_friend(user2)

page = Admin_Page("My Page")
user1.create_post("Hello, World!", page)
user2.like_post(page.posts[0])

print("Page Name:", page.name)
print("Post Content:", page.posts[0].content)
print("Likes:", len(page.posts[0].likes))
